# Rydex – Android app (v1.0, wraps the prototype)

Packages the Rydex prototype (app/src/main/assets/index.html) as an Android app.

## Build the APK on GitHub (no Android Studio needed)
1. Create a new repository on GitHub (e.g. rydex-android).
2. Upload ALL files from this folder to the repo's main branch.
   Make sure the hidden folder .github/workflows/build-apk.yml is uploaded too.
3. Open the repo's Actions tab. The "Build APK" workflow starts by itself (about 5-8 minutes).
   You can also start it manually: Actions > Build APK > Run workflow.
4. When it turns green, open the run and download "rydex-debug-apk" from Artifacts.
   Unzip it to get app-debug.apk, then install it on your phone
   (allow "Install unknown apps" for your file manager or browser).

## Build with Android Studio instead
Open this folder in Android Studio, wait for Gradle sync, then Build > Build APK(s).

## Update the app screens
Replace app/src/main/assets/index.html with a newer version and push again. GitHub rebuilds the APK.

## Notes
- Debug APK only. For Play Store or a signed release APK you need a signing key (ask for help).
- Needs internet only for the Google Fonts; everything else runs from the app.
- Demo only: data is saved on the phone, there is no server, real map, payment or SMS yet.
- Browser notifications and Share do not work inside a WebView; the app falls back to in-app messages.
- applicationId is com.rydex.app. Change it before publishing anywhere.
