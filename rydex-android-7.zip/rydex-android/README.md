# Rydex – Android apps (v2.0)

Two apps are built from this one project:
- Rydex          (customer app, com.rydex.app)
- Rydex Captain  (driver app, com.rydex.captain)

Both run the same screens (app/src/main/assets/index.html); the app picks its mode from the URL (?app=customer / ?app=captain).

## Real map
Inside the apps the map is OpenStreetMap (Leaflet) with real routes (OSRM), place search and reverse lookup (Nominatim) and GPS.
These free public services are for demos. For a real launch use a paid provider (Google Maps, Mapbox, MapTiler) with your own key.
Without internet the apps fall back to the simple drawn map.

## Build on GitHub
1. Upload this zip to the repo's main branch (keep the workflow file at .github/workflows/).
2. Actions > Build APK builds both apps (about 5 minutes).
3. Download the "rydex-apks" artifact. It contains app-customer-debug.apk and app-captain-debug.apk.

## Notes
- Demo only: the two apps are NOT connected to each other yet. Matching a customer ride with a captain needs a backend (for example Firebase).
- Debug APKs only. Play Store needs a signing key.
