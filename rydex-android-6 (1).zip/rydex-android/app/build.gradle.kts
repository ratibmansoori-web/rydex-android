plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.rydex.app"
    compileSdk = 34
    defaultConfig {
        minSdk = 24
        targetSdk = 34
        versionCode = 2
        versionName = "2.0"
    }
    buildFeatures { buildConfig = true }
    flavorDimensions += "role"
    productFlavors {
        create("customer") {
            dimension = "role"
            applicationId = "com.rydex.app"
            resValue("string", "app_name", "Rydex")
            buildConfigField("String", "APP_MODE", "\"customer\"")
        }
        create("captain") {
            dimension = "role"
            applicationId = "com.rydex.captain"
            resValue("string", "app_name", "Rydex Captain")
            buildConfigField("String", "APP_MODE", "\"captain\"")
        }
    }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("androidx.webkit:webkit:1.10.0")
}
